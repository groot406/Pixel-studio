/**
 * Pixel Studio AI patch engine: zero dependencies, browser + Node 20+.
 *
 * Input project is normalized indexed data:
 * { width, height, palette:['#RRGGBB',...],
 *   layers:[{name,visible,locked},...],
 *   animations:[{name, fps, frames:[{duration, cels:[Int16Array|number[],...]}, ...]}, ...] }
 * Every cel has width*height slots: -1 means transparent, 0..palette.length-1 are indexes.
 *
 * The host Pixel Studio app must adapt its internal state to/from this shape.
 */
const MAX_CANVAS = 256;
const MAX_LAYERS = 32;
const MAX_PALETTE = 32;
const MAX_SLOTS = 4_194_304; // bounded file/AI preview allocation
const HEX = /^#[0-9a-fA-F]{6}$/;
const COLOR_CODES = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
const HEX16 = /^[a-f0-9]{16}$/;

function requireInt(n, min, max, name) {
  if (!Number.isSafeInteger(n) || n < min || n > max) throw new Error(`${name} must be an integer from ${min} to ${max}`);
  return n;
}
function nameOk(s, label) {
  if (typeof s !== 'string' || !s.trim() || s.length > 200) throw new Error(`Invalid ${label}`);
  return s;
}
function normalizeHex(hex) {
  if (!HEX.test(hex)) throw new Error(`Invalid palette color: ${String(hex)}`);
  return hex.toUpperCase();
}
function assertProject(p) {
  if (!p || typeof p !== 'object') throw new Error('Missing project');
  requireInt(p.width, 1, MAX_CANVAS, 'Width');
  requireInt(p.height, 1, MAX_CANVAS, 'Height');
  if (!Array.isArray(p.palette) || p.palette.length < 1 || p.palette.length > MAX_PALETTE) throw new Error('Invalid palette');
  p.palette.forEach(normalizeHex);
  if (!Array.isArray(p.layers) || p.layers.length < 1 || p.layers.length > MAX_LAYERS) throw new Error('Invalid layers');
  p.layers.forEach((l, i) => {
    nameOk(l.name, `layer ${i} name`);
    if (typeof l.visible !== 'boolean' || typeof l.locked !== 'boolean') throw new Error(`Invalid layer ${i} flags`);
  });
  if (!Array.isArray(p.animations) || !p.animations.length) throw new Error('Missing animations');
  let slots = 0;
  for (const [ai, a] of p.animations.entries()) {
    nameOk(a.name, `animation ${ai} name`);
    requireInt(a.fps, 1, 60, `Animation ${ai} FPS`);
    if (!Array.isArray(a.frames) || !a.frames.length) throw new Error(`Animation ${ai} needs frames`);
    for (const [fi, f] of a.frames.entries()) {
      requireInt(f.duration, 1, 60_000, `Frame ${ai}/${fi} duration`);
      if (!Array.isArray(f.cels) || f.cels.length !== p.layers.length) throw new Error(`Frame ${ai}/${fi} has invalid cels`);
      slots += p.width * p.height * p.layers.length;
      if (slots > MAX_SLOTS) throw new Error('Project exceeds AI-edit preview pixel budget');
      for (let li = 0; li < f.cels.length; li++) {
        const cel = f.cels[li];
        if (!Array.isArray(cel) && !(cel instanceof Int16Array)) throw new Error(`Invalid cel ${ai}/${fi}/${li}`);
        if (cel.length !== p.width * p.height) throw new Error(`Wrong cel size ${ai}/${fi}/${li}`);
        for (let k = 0; k < cel.length; k++) {
          const value = cel[k];
          if (!Number.isInteger(value) || value < -1 || value >= p.palette.length) throw new Error(`Invalid pixel index in ${ai}/${fi}/${li}`);
        }
      }
    }
  }
  return p;
}

/** Non-cryptographic 64-bit state fingerprint, useful for stale proposal checks. */
export function projectFingerprint(p) {
  assertProject(p);
  let a = 0x811c9dc5, b = 0x9e3779b9;
  const feed = n => {
    a = Math.imul(a ^ (n & 255), 0x01000193) >>> 0;
    b = Math.imul((b + (n & 255)) >>> 0, 0x85ebca6b) >>> 0;
  };
  const string = s => { for (const cp of new TextEncoder().encode(s)) feed(cp); feed(0); };
  feed(p.width); feed(p.width >>> 8); feed(p.height); feed(p.height >>> 8);
  for (const c of p.palette) string(c.toUpperCase());
  for (const l of p.layers) { string(l.name); feed(l.visible ? 1 : 0); feed(l.locked ? 1 : 0); }
  for (const anim of p.animations) {
    string(anim.name); feed(anim.fps);
    for (const frame of anim.frames) {
      feed(frame.duration); feed(frame.duration >>> 8);
      for (const cel of frame.cels) for (const x of cel) feed(x + 1);
    }
  }
  return a.toString(16).padStart(8, '0') + b.toString(16).padStart(8, '0');
}

export function selectionRect(p, selection) {
  requireInt(selection.x, 0, p.width - 1, 'Selection x');
  requireInt(selection.y, 0, p.height - 1, 'Selection y');
  requireInt(selection.width, 1, p.width, 'Selection width');
  requireInt(selection.height, 1, p.height, 'Selection height');
  if (selection.x + selection.width > p.width || selection.y + selection.height > p.height) throw new Error('Selection extends beyond canvas');
  return { x: selection.x, y: selection.y, width: selection.width, height: selection.height };
}

export function allowedTargets(p, {scope, animationIndex, frameIndex, layerIndex}) {
  requireInt(animationIndex, 0, p.animations.length - 1, 'Animation index');
  requireInt(frameIndex, 0, p.animations[animationIndex].frames.length - 1, 'Frame index');
  requireInt(layerIndex, 0, p.layers.length - 1, 'Layer index');
  if (p.layers[layerIndex].locked) throw new Error('Cannot inpaint a locked layer');
  if (!['frame', 'animation'].includes(scope)) throw new Error('Scope must be frame or animation');
  const frames = scope === 'frame' ? [frameIndex] : p.animations[animationIndex].frames.map((_, i) => i);
  return frames.map(fi => ({ animationIndex, frameIndex: fi, layerIndex }));
}

const targetKey = ({animationIndex, frameIndex, layerIndex}) => `${animationIndex}/${frameIndex}/${layerIndex}`;
const allLines = text => {
  if (typeof text !== 'string' || text.length > 2_000_000) throw new Error('Invalid or oversized AI output');
  return text.replace(/\r\n?/g, '\n').split('\n').map(x => x.trim()).filter(x => x && !x.startsWith('#'));
};
function parts(line, verb) {
  const p = line.split(/\s+/);
  if (p[0] !== verb) throw new Error(`Expected ${verb}, got ${p[0]}`);
  return p;
}
const asInt = (s, label) => {
  if (!/^(0|[1-9]\d*)$/.test(s ?? '')) throw new Error(`Invalid ${label}: ${s}`);
  return Number(s);
};

/** Expand 0-9A-Z palette codes; '.' means clear, e.g. A{3}.0{2}. */
export function expandPixelRun(src, maxLength = 256) {
  if (typeof src !== 'string' || !src.length) throw new Error('SPAN needs pixels');
  const out = [];
  let i = 0;
  while (i < src.length) {
    const ch = src[i++];
    if (!COLOR_CODES.includes(ch) && ch !== '.') throw new Error(`Unsupported pixel symbol: ${ch}`);
    let repeat = 1;
    if (src[i] === '{') {
      const end = src.indexOf('}', i);
      if (end < 0) throw new Error('Unclosed pixel repeat');
      repeat = asInt(src.slice(i + 1, end), 'pixel repeat');
      if (repeat < 2) throw new Error('Repeat must be at least 2');
      i = end + 1;
    }
    if (out.length + repeat > maxLength) throw new Error('Expanded SPAN exceeds selection/canvas bounds');
    const value = ch === '.' ? -1 : COLOR_CODES.indexOf(ch);
    for (let k = 0; k < repeat; k++) out.push(value);
  }
  return out;
}

/**
 * AI returns a *small patch*, never the entire project. Selection and targets are
 * strict: no out-of-bounds, locked layers, palette mutation, or unselected frames.
 */
export function parseInpaintPatch(text) {
  const lines = allLines(text);
  let idx = 0;
  if (lines[idx++] !== 'PXAINPAINT 1') throw new Error('Expected PXAINPAINT 1');
  const size = parts(lines[idx++] ?? '', 'SIZE');
  if (size.length !== 3) throw new Error('SIZE needs width and height');
  const rect = parts(lines[idx++] ?? '', 'RECT');
  if (rect.length !== 5) throw new Error('RECT needs x y width height');
  const base = parts(lines[idx++] ?? '', 'BASE');
  if (base.length !== 2 || !HEX16.test(base[1])) throw new Error('Invalid BASE fingerprint');
  const targets = [];
  let current = null;
  while (idx < lines.length) {
    const line = lines[idx++];
    const p = line.split(/\s+/);
    if (p[0] === 'TARGET') {
      if (p.length !== 4) throw new Error('TARGET needs animation frame layer indexes');
      current = {
        animationIndex: asInt(p[1], 'animation index'),
        frameIndex: asInt(p[2], 'frame index'),
        layerIndex: asInt(p[3], 'layer index'),
        spans: []
      };
      targets.push(current);
    } else if (p[0] === 'SPAN') {
      if (!current) throw new Error('SPAN must follow TARGET');
      if (p.length !== 4) throw new Error('SPAN needs y x pixels');
      current.spans.push({y: asInt(p[1], 'span y'), x: asInt(p[2], 'span x'), pixels: p[3]});
    } else throw new Error(`Unsupported command: ${p[0]}`);
  }
  if (!targets.length) throw new Error('No TARGET in AI response');
  return {
    width: asInt(size[1], 'width'), height: asInt(size[2], 'height'),
    rect: {x: asInt(rect[1], 'x'), y: asInt(rect[2], 'y'), width: asInt(rect[3], 'width'), height: asInt(rect[4], 'height')},
    base: base[1], targets
  };
}

export function previewInpaint(project, text, request) {
  assertProject(project);
  const rect = selectionRect(project, request.selection);
  const allowed = new Set(allowedTargets(project, request).map(targetKey));
  const patch = parseInpaintPatch(text);
  if (patch.width !== project.width || patch.height !== project.height) throw new Error('AI response canvas size differs');
  if (JSON.stringify(patch.rect) !== JSON.stringify(rect)) throw new Error('AI response selection differs');
  const fingerprint = projectFingerprint(project);
  if (patch.base !== fingerprint || (request.baseFingerprint && request.baseFingerprint !== fingerprint)) {
    throw new Error('Project changed since the AI request; create a new preview');
  }
  const animations = project.animations.slice();
  const modifiedAnim = new Map(), modifiedFrame = new Map(), modifiedCel = new Map();
  let changes = 0;
  const altered = new Map();
  for (const target of patch.targets) {
    const key = targetKey(target);
    if (!allowed.has(key)) throw new Error(`AI tried to modify an out-of-scope target ${key}`);
    const {animationIndex: a, frameIndex: f, layerIndex: l} = target;
    if (!modifiedAnim.has(a)) {
      animations[a] = {...animations[a], frames: animations[a].frames.slice()};
      modifiedAnim.set(a, animations[a]);
    }
    const fk = `${a}/${f}`;
    if (!modifiedFrame.has(fk)) {
      const frame = animations[a].frames[f];
      animations[a].frames[f] = {...frame, cels: frame.cels.slice()};
      modifiedFrame.set(fk, animations[a].frames[f]);
    }
    if (!modifiedCel.has(key)) {
      const source = project.animations[a].frames[f].cels[l];
      const clone = new Int16Array(source);
      animations[a].frames[f].cels[l] = clone;
      modifiedCel.set(key, clone);
    }
    const dest = modifiedCel.get(key);
    for (const span of target.spans) {
      if (span.y < rect.y || span.y >= rect.y + rect.height || span.x < rect.x || span.x >= rect.x + rect.width) throw new Error('SPAN begins outside the selected area');
      const len = rect.x + rect.width - span.x;
      const expanded = expandPixelRun(span.pixels, len);
      for (let i = 0; i < expanded.length; i++) {
        const color = expanded[i];
        if (color >= project.palette.length) throw new Error(`Pixel uses unavailable palette slot ${color}`);
        dest[span.y * project.width + span.x + i] = color;
      }
    }
    altered.set(key, {animationIndex:a, frameIndex:f, layerIndex:l});
  }
  // Count actual changed pixels, rather than written SPAN entries.
  const perTarget = [];
  for (const [key, {animationIndex:a, frameIndex:f, layerIndex:l}] of altered) {
    const old = project.animations[a].frames[f].cels[l];
    const updated = modifiedCel.get(key);
    let count = 0;
    for (let y = rect.y; y < rect.y + rect.height; y++) {
      for (let x = rect.x; x < rect.x + rect.width; x++) {
        const k = y * project.width + x;
        if (old[k] !== updated[k]) count++;
      }
    }
    changes += count;
    perTarget.push({key, changedPixels: count});
  }
  if (!changes) throw new Error('AI proposal does not change any pixels');
  return {
    project: {...project, animations},
    changedPixels: changes, perTarget,
    selection: rect,
    baseFingerprint: fingerprint
  };
}

export function buildInpaintPrompt({project, request, description, originalPxa}) {
  assertProject(project);
  const rect = selectionRect(project, request.selection);
  const targets = allowedTargets(project, request);
  nameOk(description, 'edit description');
  if (typeof originalPxa !== 'string' || !originalPxa.startsWith('PXA 1\n')) throw new Error('Export current project to PXA 1 before AI editing');
  return `Edit only selected pixels in this indexed Pixel Studio project.\nArtwork request: ${description}\n\n` +
    `RULES: Output ONLY PXAINPAINT 1 text, no Markdown fences. Do not change palette, pixel size, animations, frame timing, layer structure, or any outside pixels. ` +
    `Use a sparse list of SPAN rows. Each SPAN overwrites the specified pixels; omitted pixels keep their prior values. ` +
    `Allowed palette codes: ${COLOR_CODES.slice(0,project.palette.length)}. Dot (.) clears to transparency. ` +
    `Use X{n} to repeat a palette code or dot n times. The selection is inclusive at left/top, exclusive at right/bottom.\n\n` +
    `REQUIRED HEADER:\nPXAINPAINT 1\nSIZE ${project.width} ${project.height}\nRECT ${rect.x} ${rect.y} ${rect.width} ${rect.height}\nBASE ${projectFingerprint(project)}\n` +
    `ALLOWED TARGETS (zero-based animation, frame, layer indexes; no others):\n${targets.map(t=>`TARGET ${t.animationIndex} ${t.frameIndex} ${t.layerIndex}`).join('\n')}\n` +
    `Each TARGET may contain SPAN y x pixel-string lines, e.g. SPAN ${rect.y} ${rect.x} 0{3}1. ` +
    `At least one changed pixel must be present. Keep all edits inside the RECT.\n\n` +
    `PROJECT PXA CONTEXT (READ-ONLY):\n${originalPxa}`;
}

export function parsePalettePatch(text) {
  const lines = allLines(text);
  if (lines[0] !== 'PXAPALETTE 1') throw new Error('Expected PXAPALETTE 1');
  const base = parts(lines[1] ?? '', 'BASE');
  if (base.length !== 2 || !HEX16.test(base[1])) throw new Error('Invalid BASE fingerprint');
  const changes = new Map();
  for (const line of lines.slice(2)) {
    const p = parts(line, 'SET');
    if (p.length !== 3) throw new Error('SET needs palette index and hex color');
    const idx = asInt(p[1], 'palette index');
    if (changes.has(idx)) throw new Error('Duplicate palette index');
    changes.set(idx, normalizeHex(p[2]));
  }
  if (!changes.size) throw new Error('No palette colors proposed');
  return {base: base[1], changes};
}
export function previewRecolor(project, text, {baseFingerprint} = {}) {
  assertProject(project);
  const patch = parsePalettePatch(text);
  const expected = projectFingerprint(project);
  if (patch.base !== expected || (baseFingerprint && baseFingerprint !== expected)) throw new Error('Project changed since AI request; create a new preview');
  const palette = project.palette.slice();
  const swatches = [];
  for (const [idx, next] of patch.changes) {
    if (idx >= palette.length) throw new Error(`Palette slot ${idx} does not exist`);
    const prev = palette[idx].toUpperCase();
    if (prev === next) continue;
    palette[idx] = next;
    swatches.push({index: idx, before: prev, after: next});
  }
  if (!swatches.length) throw new Error('No actual palette changes');
  return {project: {...project, palette}, swatches, baseFingerprint: expected,
    warning: 'This indexed palette is shared: recoloring affects every frame and animation that uses these color slots.'};
}
export function buildRecolorPrompt({project, description}) {
  assertProject(project);
  nameOk(description, 'palette description');
  return `Recolor the existing indexed palette of Pixel Studio. Request: ${description}\n` +
    `Return ONLY PXAPALETTE 1, BASE, and SET lines. Do not change pixel coordinates, indices, layers, frame counts, timing, or colors not explicitly selected with SET.\n` +
    `Existing slots:\n${project.palette.map((c,i)=>`${i} ${COLOR_CODES[i]} ${c}`).join('\n')}\n` +
    `Use color hex #RRGGBB; sample output:\nPXAPALETTE 1\nBASE ${projectFingerprint(project)}\nSET 0 #112233\n` +
    `The palette is shared across the entire project, so keep semantic relationships between shadows, midtones and highlights.\n` +
    `Return appropriate SET lines for the request.`;
}

export function compositeFrame(project, animationIndex, frameIndex) {
  assertProject(project);
  const anim = project.animations[animationIndex];
  if (!anim) throw new Error('Unknown animation');
  const frame = anim.frames[frameIndex];
  if (!frame) throw new Error('Unknown frame');
  const composite = new Int16Array(project.width * project.height).fill(-1);
  for (let li = 0; li < project.layers.length; li++) {
    if (!project.layers[li].visible) continue;
    const cel = frame.cels[li];
    for (let i = 0; i < cel.length; i++) if (cel[i] >= 0) composite[i] = cel[i];
  }
  return composite;
}

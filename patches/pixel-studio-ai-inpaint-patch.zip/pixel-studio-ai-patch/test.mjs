import test from 'node:test';
import assert from 'node:assert/strict';
import {buildInpaintPrompt, projectFingerprint, previewInpaint, parseInpaintPatch, expandPixelRun, buildRecolorPrompt, previewRecolor, compositeFrame} from './ai-edit-core.mjs';
function project(w = 8, h = 8) {
  const pixels = () => new Int16Array(w*h).fill(-1);
  const p = {width:w,height:h,palette:['#123456','#ABCDEF','#FFEEDD'], layers:[{name:'BG',visible:true,locked:true},{name:'Artwork',visible:true,locked:false}], animations:[{name:'Idle',fps:8,frames:[{duration:125,cels:[pixels(),pixels()]},{duration:125,cels:[pixels(),pixels()]}]},{name:'Walk',fps:8,frames:[{duration:125,cels:[pixels(),pixels()]}]}]};
  p.animations[0].frames[0].cels[1][2*w+2] = 0;
  p.animations[0].frames[1].cels[1][2*w+2] = 0;
  return p;
}
function header(p,rect={x:1,y:1,width:3,height:3}) { return `PXAINPAINT 1\nSIZE ${p.width} ${p.height}\nRECT ${rect.x} ${rect.y} ${rect.width} ${rect.height}\nBASE ${projectFingerprint(p)}\n`; }
const req = {scope:'frame',animationIndex:0,frameIndex:0,layerIndex:1,selection:{x:1,y:1,width:3,height:3}};
test('valid inpaint edits only ROI, only one frame/layer, Undo-ready immutable',()=>{
  const p=project(), text=header(p)+'TARGET 0 0 1\nSPAN 1 1 1{2}2\nSPAN 2 2 .';
  const r=previewInpaint(p,text,req);
  assert.equal(r.changedPixels,4);
  assert.equal(r.project.animations[0].frames[0].cels[1][1*8+1],1);
  assert.equal(r.project.animations[0].frames[0].cels[1][2*8+2],-1);
  assert.equal(p.animations[0].frames[0].cels[1][2*8+2],0);
  assert.strictEqual(r.project.animations[0].frames[1],p.animations[0].frames[1]);
  assert.deepEqual(r.project.layers,p.layers);
});
test('allowed animation scope applies changes in multiple frames',()=>{
  const p=project(),text=header(p)+'TARGET 0 0 1\nSPAN 1 1 1\nTARGET 0 1 1\nSPAN 1 1 2';
  const r=previewInpaint(p,text,{...req,scope:'animation'});
  assert.equal(r.changedPixels,2);
  assert.equal(r.project.animations[0].frames[1].cels[1][9],2);
});
test('reject outside rectangle, row overflow, wrong frame, locked layer, bogus palette and stale output',()=>{
  const p=project();
  for (const body of ['TARGET 0 0 1\nSPAN 1 0 1','TARGET 0 0 1\nSPAN 1 3 11','TARGET 0 1 1\nSPAN 1 1 1','TARGET 0 0 0\nSPAN 1 1 1','TARGET 0 0 1\nSPAN 1 1 A']) {
    assert.throws(()=>previewInpaint(p,header(p)+body,req));
  }
  assert.throws(()=>previewInpaint(p,header(p).replace(projectFingerprint(p),'0000000000000000')+'TARGET 0 0 1\nSPAN 1 1 1',req),/changed/);
  assert.throws(()=>previewInpaint(p,header(p)+'TARGET 0 0 1\nSPAN 2 2 0',req),/does not change/);
});
test('RLE is bounded, rejects malformed expressions',()=>{
  assert.deepEqual(expandPixelRun('2{3}.0{2}'),[2,2,2,-1,0,0]);
  assert.throws(()=>expandPixelRun('A{9999}',3));
  assert.throws(()=>expandPixelRun('a'));
  assert.throws(()=>expandPixelRun('0{1}'));
  assert.throws(()=>expandPixelRun('0{X}'));
});
test('prompts include exact scope, fingerprint and PXA context',()=>{
  const p=project();
  const prompt=buildInpaintPrompt({project:p,request:req,description:'Add a red hat',originalPxa:'PXA 1\nSIZE 8 8'});
  assert.match(prompt,/TARGET 0 0 1/);
  assert.match(prompt,/RECT 1 1 3 3/);
  assert.match(prompt,/PXA 1\nSIZE 8 8/);
  assert.match(prompt,new RegExp(projectFingerprint(p)));
});
test('recolor changes palette only across all frames, reports swatch diffs',()=>{
  const p=project(), text=`PXAPALETTE 1\nBASE ${projectFingerprint(p)}\nSET 0 #fefefe\nSET 2 #112233`;
  const r=previewRecolor(p,text);
  assert.equal(r.swatches.length,2);
  assert.deepEqual(r.project.palette,['#FEFEFE','#ABCDEF','#112233']);
  assert.strictEqual(r.project.animations,p.animations);
  assert.equal(p.palette[0],'#123456');
  assert.match(r.warning,/every frame/);
  assert.match(buildRecolorPrompt({project:p,description:'Make it icy'}),/PXAPALETTE 1/);
  assert.throws(()=>previewRecolor(p,`PXAPALETTE 1\nBASE ${projectFingerprint(p)}\nSET 3 #123456`));
});
test('composite respects visible layer and transparent pixels',()=>{
  const p=project(); const c=compositeFrame(p,0,0);
  assert.equal(c[2*8+2],0);
  assert.equal(c[0],-1);
});
test('max canvas 256x256 supported with lightweight project',()=>{
  const p=project(256,256);
  const text=header(p,{x:252,y:252,width:4,height:4})+'TARGET 0 0 1\nSPAN 255 252 1{4}';
  const r=previewInpaint(p,text,{...req,selection:{x:252,y:252,width:4,height:4}});
  assert.equal(r.changedPixels,4);
  assert.equal(r.project.animations[0].frames[0].cels[1][255*256+255],1);
});
